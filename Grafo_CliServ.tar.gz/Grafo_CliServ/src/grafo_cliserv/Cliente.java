/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafo_cliserv;

import grafo_cliserv.*;
import java.util.Scanner;

import org.apache.thrift.TException;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.protocol.TBinaryProtocol;

/**
 *
 * @author neliton
 */
public class Cliente {

    public static void main(String[] args) {
        int op = -1;
        int nomeV, corV;
        String descricaoV;
        double pesoV;
        int nomeV1, nomeV2;
        int direcaoV;
        boolean dir;
        
        Scanner ler = new Scanner(System.in);
        try {
            TTransport transport = new TSocket("localhost", 9090);
            transport.open();

            TProtocol protocol = new TBinaryProtocol(transport);
            Func_Grafo.Client cliente = new Func_Grafo.Client(protocol);
            
            System.out.println("ok");
            
            
            
            while (op != 0) {
                System.out.println("Entre com a opção:");
                System.out.println("1 - Adicionar vértice");
                System.out.println("2 - Adicionar aresta");
                System.out.println("3 - Remover vértice");
                System.out.println("4 - Remover aresta");
                System.out.println("5 - Listar vértices vizinhos");
                System.out.println("6 - Listar arestas do vértice");
                System.out.println("7 - Mostrar grafo(lista de arestas)");
                System.out.println("0 - Sair");
                
                op = ler.nextInt();
                
                switch(op)
                {
                    case 1:
                        System.out.println("Entre com nome (int), cor (int), descricao e peso do vértice:");
          
                        nomeV = ler.nextInt();
                        corV = ler.nextInt();
                        descricaoV = ler.next();
                        pesoV = ler.nextDouble();
                        
                        cliente.criarVertice(nomeV, corV, descricaoV, pesoV);
                        break;
                    
                    case 2:
                        System.out.println("Entre com nome (int) do vértice1, nome (int) do vértice2, 0ou1 para direção e peso:");
                        nomeV1 = ler.nextInt();
                        nomeV2 = ler.nextInt();
                        direcaoV = ler.nextInt();
                        if(direcaoV == 1)
                            dir = true;
                        else
                            dir = false;
                        pesoV = ler.nextDouble();
                        
                        cliente.criarAresta(nomeV1, nomeV2, pesoV, dir);
                        break;
                    
                    case 3:
                        System.out.println("Entre com o nome do vértice a ser removido");
                        nomeV = ler.nextInt();
                        
                        cliente.deletarVertice(nomeV);
                        break;
                    
                    case 4:
                        System.out.println("Entre com o nome do vértice1 e vértice2 da aresta");
                        nomeV1 = ler.nextInt();
                        nomeV2 = ler.nextInt();
                        
                        cliente.deletarAresta(nomeV1, nomeV2);
                        break;
                    
                    case 5:
                        System.out.println("Entre com o nome do vértice");
                        nomeV = ler.nextInt();
                        
                        cliente.listarVerticesVizinhos(nomeV);
                        break;
                    
                    case 6:
                        System.out.println("Entre com o nome do vértice");
                        nomeV = ler.nextInt();
                        
                        cliente.listarArestasVertice(nomeV);
                        break;
                    
                    case 7:
                        cliente.lerAresta(1);
                        break;
                    
                    case 0:
                        transport.close();
                        break;          
                }
            }
            transport.close();

        } catch (TException x) {
            x.printStackTrace();
        }
    }

}
