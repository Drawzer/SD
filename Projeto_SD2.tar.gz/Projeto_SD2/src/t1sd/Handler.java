/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1sd;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.thrift.TException;
import org.apache.thrift.protocol.TBinaryProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import static t1sd.GrafoClient.retornaServidorV;

/**
 *
 * @author patrick
 */
public class Handler implements Grafosd.Iface{
    Grafo g;
    
    @Override
    public String criaGrafo(Grafo g){
        this.g=g;
        return "";
    }
    
    @Override
    public String addVertice(long nome, long cor, java.lang.String descricao, double peso){
        int verifica=0;
        for(Vertice w : g.vertices){
            if(w.nome==nome)
                verifica=1;
        }
        if(verifica==0){
            Vertice v = new Vertice(nome,cor,descricao,peso);
            this.g.vertices.add(v);
            System.out.println("asa");
            return("Vertice ["+nome+"] adicionado!");

        }
        else{
            System.out.println("asa");
            return("Vertice ja existe");
            }
    }
    
    @Override
    public String addAresta(long id, long origem, long destino, double peso, long flag, java.lang.String descricao) throws TTransportException, TException{
        int verifica=0;
        String retorno;
        
        int v1=0;
        int v2=0;
        
        int s1=0;
        int s2=0;
        
        long aux;
        
        v1 = (int)origem;
        v2 = (int)destino;
        
        try {
            s1 = retornaServidorV(v1);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            s2 = retornaServidorV(v2);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        TTransport transport = new TSocket("localhost",9090+s1);
        transport.open();
        TProtocol protocol = new TBinaryProtocol( transport );
        Grafosd.Client client = new Grafosd.Client(protocol);
        
        retorno = client.lerVertice(origem);
        System.out.println(retorno);
        if(retorno.equalsIgnoreCase("existe"))
            verifica++;
        Aresta a = new Aresta(id,origem,destino,peso,flag,descricao);
        
       
        client.adicionarAdj(a,origem);
        
        transport.close();
        
        transport = new TSocket("localhost",9090+s2);
        transport.open();
        protocol = new TBinaryProtocol( transport );
        client = new Grafosd.Client(protocol);
        
        retorno = client.lerVertice(destino);
        System.out.println(retorno);
        if(retorno.equalsIgnoreCase("existe"))
            verifica++;
        
        aux = a.origem;
        a.origem = a.destino;
        a.destino = aux;
        
        client.adicionarAdj(a,destino);
        transport.close();
        
        
        if(verifica==2){
            a = new Aresta(id,origem,destino,peso,flag,descricao);
            g.arestas.add(a);
            for(Vertice v: g.vertices){
                if(v.nome==origem)
                    v.adj.add(a);
            }
            if(flag==1){
                Aresta b = new Aresta(id,destino,origem,peso,flag,descricao);
                g.arestas.add(b);
                for(Vertice v: g.vertices){
                    if(v.nome==destino)
                        v.adj.add(b);
                }
            }
            return ("Aresta adicionada!");
        }
        else
           return("Um ou mais vertices nao estao no grafo");
    }
    
    @Override
    public String imprimeGrafo(){
        Vertice u = new Vertice(-10,0,"balela",10);
        
        String retorno = "";
        StringBuilder strBuilder = new StringBuilder(retorno);
        
        for(Vertice v: g.vertices){
            strBuilder.append(v.nome);
            strBuilder.append("->");
            for(Aresta a : v.adj){
                u.nome = a.destino;
                strBuilder.append(u.nome);
                strBuilder.append(",");
            }
            strBuilder.append("\n");
        }
        return strBuilder.toString();
    
    }

    
    public String adicionarAdj(Aresta a, long nomeV)
    {
        for(Vertice v: g.vertices){
                if(v.nome==nomeV)
                    v.adj.add(a);
            }
        return("Lista de adjacencia atualizada!");
    }
    
    @Override
    public String removeVertice(long nome) throws TTransportException, TException{
        
        
        /*for(Vertice v : g.vertices){
            if(v.nome==nome)
                v.adj.clear();
        }*/
        String retorno = "";
        //Conecta com servidor de arestas pra remover as arestas que tenham o vertice
        //que está a ser removido
        TTransport transport = new TSocket("localhost",9093);
        transport.open();
        TProtocol protocol = new TBinaryProtocol( transport );
        Grafosd.Client client = new Grafosd.Client(protocol);
        
        //criar metodo removeArestasV que recebe o nome de um vertice e remove todas arestas
        //que tenham esse vertice
        client.removeArestasV(nome);
        retorno = retorno + "Arestas relacionadas ao vertice foram removidas!\n";
        transport.close();
        
        //agora remover o vertice da lista de adj dos q eram vizinhos dele
        
        int vert=0;
        long vertVizinho=0;
        for(Vertice v : g.vertices){
            if(v.nome == nome)
            { 
                for(Iterator<Aresta> i=v.adj.iterator();i.hasNext();){
                    Aresta a = i.next();
                    if(a.origem==nome)
                    {
                        vert = (int)a.destino;
                        vertVizinho = a.destino;
                    }
                    else if(a.destino == nome)
                    {
                        vert = (int)a.origem;
                        vertVizinho = a.origem;
                    }
                    
                    try {
                        vert = retornaServidorV(vert);
                    } catch (UnsupportedEncodingException ex) {
                        Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (NoSuchAlgorithmException ex) { 
                        Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
                    }
                        //vert tem o servidor de um dos vertices vizinhos do removido
                    transport = new TSocket("localhost",9090+vert);
                    transport.open();
                    protocol = new TBinaryProtocol( transport );
                    client = new Grafosd.Client(protocol);
                    retorno = retorno + "Atualizando lista de adj do Vertice "+vertVizinho+"!\n";    
                    client.removeListaAdj(nome,vertVizinho);                    
                }
            }
        }       

        transport.close();
        
        /*for(Vertice v : g.vertices){
            for(Iterator<Aresta> i=v.adj.iterator();i.hasNext();){
                Aresta a = i.next();
                if(a.origem==nome || a.destino==nome)
                    i.remove();
            }
        }*/
        for(Iterator<Vertice> i=g.vertices.iterator();i.hasNext();){
                Vertice v = i.next();
                if(v.nome==nome)
                    i.remove();
        }
        retorno = retorno + "\nVértice removido!\n";
        
        return retorno;
    }
    
    @Override
    public String removeAresta(long id) throws TTransportException, TException{
        long v1=0;
        long v2=0;
        int ver1=0;
        int ver2=0;
        int s1=0;
        int s2=0;
        
        String retorno = "";
        for(Iterator<Aresta> i=g.arestas.iterator();i.hasNext();){
                Aresta a = i.next();
                if(a.id==id)
                {
                    v1 = a.origem;
                    v2 = a.destino;
                    i.remove();       
                }
        }
        ver1 = (int)v1;
        ver2 = (int)v2;
        
        try {
            s1 = retornaServidorV(ver1);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
            s2 = retornaServidorV(ver2);
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Handler.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        TTransport transport = new TSocket("localhost",9090+s1);
        transport.open();
        TProtocol protocol = new TBinaryProtocol( transport );
        Grafosd.Client client = new Grafosd.Client(protocol);
        client.removeListaAdj(v1,v2);
        transport.close();
        
        transport = new TSocket("localhost",9090+s2);
        transport.open();
        protocol = new TBinaryProtocol( transport );
        client = new Grafosd.Client(protocol);
        client.removeListaAdj(v2,v1);
        transport.close();
        return("Aresta removida");
    }
    
    @Override
    public String modificaVertice(long nome, long cor, java.lang.String descricao, double peso){
        int verifica=0;
        for(Vertice v : g.vertices){
            if(v.nome==nome){
                v.cor=cor;
                v.descricao=descricao;
                v.peso=peso;
                verifica=1;
            }
        }
        if(verifica==1)
            return("Vertice modificado");
        else
            return("Vertice não modificado");
    }
    
    @Override
    public String modificaAresta(long id, double peso, java.lang.String descricao){
        int verifica=0;
        for(Aresta a : g.arestas){
            if(a.id==id){
                a.peso=peso;
                a.descricao=descricao;
                verifica=1;
            }
        }
        if(verifica==1)
            return("Aresta modificada");
        else
            return("Aresta nao modificada");
    }
    
    @Override
    public String listaVertice(long id){
        long b=0;
        long c=0;
        int verifica=0;
        for(Aresta a : g.arestas){
            if(a.id==id){
                b=a.origem;
                c=a.destino;
                verifica=1;
            }
        }
        if(verifica==1)
            return("Origem "+b+" Destino "+c);
        else
            return("Aresta nao se encontra");
    }
    
    @Override
    public String listaAresta(long nome){
        String retorno = "";
        StringBuilder strBuilder = new StringBuilder(retorno);
        
        int verifica=0;
        for(Vertice v : g.vertices){
            if(v.nome==nome){
                verifica=1;
                for(Aresta a : v.adj){
                    strBuilder.append(a.id+"\n");
                }
            }
        }
        if(verifica==0)
            return("Vertice nao se encontra");
        
        return strBuilder.toString();
    }
    
    @Override
    public String listaVizinhos(long nome){
        String retorno = "";
        StringBuilder strBuilder = new StringBuilder(retorno);
        int verifica=0;
        for(Vertice v : g.vertices){
            if(v.nome==nome){
                verifica=1;
                for(Aresta a : v.adj){
                    strBuilder.append(a.destino);
                }
            }
        }
        if(verifica==0)
            return("Vertice nao se encontra");
        
        return strBuilder.toString();
    }
    
    public static int retornaServidorV(int verticeNome) throws UnsupportedEncodingException, NoSuchAlgorithmException
    {
        
            int vetValores[] = new int[32];
            int j;
            int soma=0;
            String servidorAux = Integer.toHexString(verticeNome);
            
            
            byte[] bytesOfMessage = servidorAux.getBytes("UTF-8");

            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] thedigest = md.digest(bytesOfMessage);
            
            for(j=0; j<thedigest.length; j++)
            {
                vetValores[j] = thedigest[j];
                
            }
            
            for(j=0; j<thedigest.length; j++)
            {
                soma += vetValores[j];
                
            }
            
            soma = Math.abs(soma%3);
            
            return soma;
    }
    
    @Override
    public String lerAresta(long id){
        return("alameda");
    }
    
    @Override
    public String lerVertice(long nome){
        String verifica = null;
        for(Vertice v : g.vertices){
            if(v.nome==nome)
                verifica ="existe";
            else
                verifica="nao existe";
        }
        return verifica;
    }

    @Override
    public String removeArestasV(long nomeV) throws TException {
        for(Iterator<Aresta> i=g.arestas.iterator();i.hasNext();)
        {
            Aresta a = i.next();
            if(a.origem==nomeV || a.destino==nomeV)
            {
                i.remove();
            }     
        }   
        return("Arestas do vértice (nome = "+nomeV+") removidas!");
    }

    @Override
    public String removeListaAdj(long nomeV, long nomeVRemovido) throws TException 
    {
        for(Vertice v : g.vertices)
        {
            if(v.nome == nomeV)
            {
        	for(Iterator<Aresta> i=v.adj.iterator();i.hasNext();)
                {
        	    Aresta a = i.next();
        	    if(a.origem==nomeVRemovido || a.destino==nomeVRemovido)
        	        i.remove();
        	}
            }
        }
        return("Lista de adjacência atualizada!");
    }

    @Override
    public String encontrarMenorCaminhoDijkstra(long nomeV1, long nomeV2) throws TException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
