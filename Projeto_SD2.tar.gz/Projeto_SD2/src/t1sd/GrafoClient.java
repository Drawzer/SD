package t1sd;
/**
 *
 * @author patrick
 */
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import t1sd.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Semaphore;
import org.apache.thrift.TException ;
import org.apache.thrift.transport.TTransport ;
import org.apache.thrift.transport.TSocket ;
import org.apache.thrift.protocol.TProtocol ;
import org.apache.thrift.protocol.TBinaryProtocol ;

public class GrafoClient {
    public static void main ( String [] args ) throws InterruptedException, UnsupportedEncodingException, NoSuchAlgorithmException {
        try{
            
            
            int servidor=0;  
            int i=-1;
            int nomeVertice;
            int nomeVertice2;
            long nomeV;
            long cor;
            String descricao;
            long flag;
            long id;
            long origem;
            long destino;
            double peso;
            String retorno;
            Scanner ler = new Scanner(System.in);
            while(i!=0){
                System.out.println("Escolha a opcao:");
                System.out.println("1- adicionar vertice");
                System.out.println("2- adicionar aresta");
                System.out.println("3- remover vertice");
                System.out.println("4- remover aresta");
                System.out.println("5- imprimi grafo");
                System.out.println("6- modificar vertice");
                System.out.println("7- modificar aresta");
                System.out.println("8- lista vertices da aresta");
                System.out.println("9- lista arestas de um vertice");
                System.out.println("10- lista vizinhos de um vertice");
                i=ler.nextInt();
                if(i==1){
                    System.out.println("Informe o nome,cor,descricao e peso");
                    nomeV=ler.nextLong();
                    cor=ler.nextLong();
                    descricao=ler.next();
                    peso=ler.nextDouble();
                    
                    nomeVertice = (int)nomeV;
                    servidor = retornaServidorV(nomeVertice);
                    TTransport transport = new TSocket("localhost",9090+servidor);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    
                    retorno = client.addVertice(nomeV, cor, descricao, peso);
                    System.out.println(retorno);
                    transport.close() ;
                }
                if(i==2){
                    System.out.println("Informe a id,origem,destino,peso,flag,descricao");
                    id=ler.nextLong();
                    origem=ler.nextLong();
                    destino=ler.nextLong();
                    peso=ler.nextDouble();
                    flag=ler.nextLong();
                    descricao=ler.next();
                    
                    nomeVertice = (int)origem;
                    nomeVertice2 = (int)destino;
                    servidor = retornaServidorA(nomeVertice, nomeVertice2);
                    TTransport transport = new TSocket("localhost",9093);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.addAresta(id, origem, destino, peso, flag, descricao);
                    
                    System.out.println(retorno);
                    transport.close() ;
                }
                if(i==3){
                    
                    
                    System.out.println("Informe o nome do vertice a ser removido");
                    nomeV=ler.nextLong();
                    nomeVertice = (int)nomeV;
                    
                    servidor = retornaServidorV(nomeVertice);
                    TTransport transport = new TSocket("localhost",9090+servidor);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.removeVertice(nomeV);
                    System.out.println(retorno);
                    transport.close();
                }
                if(i==4){
                    System.out.println("Informe o id da aresta a ser removida");
                    id=ler.nextLong();
                    
                    TTransport transport = new TSocket("localhost",9093);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    retorno = client.removeAresta(id);
                    System.out.println(retorno);
                    transport.close();
                }
                if(i==5)
                {
                    TTransport transport = new TSocket("localhost",9090);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    retorno = client.imprimeGrafo();
                    System.out.println(retorno);
                    transport.close();
                    
                    transport = new TSocket("localhost",9091);
                    transport.open();
                    protocol = new TBinaryProtocol( transport );
                    client = new Grafosd.Client(protocol);
                    retorno = client.imprimeGrafo();
                    System.out.println(retorno);
                    transport.close();
                    
                    transport = new TSocket("localhost",9092);
                    transport.open();
                    protocol = new TBinaryProtocol( transport );
                    client = new Grafosd.Client(protocol);
                    retorno = client.imprimeGrafo();
                    System.out.println(retorno);
                    transport.close();
                     
                }
                if(i==6){
                    System.out.println("Informe o nome,cor,descricao,peso do vertice a ser modificado");
                    nomeV=ler.nextLong();
                    cor=ler.nextLong();
                    descricao=ler.next();
                    peso=ler.nextDouble();
                    
                    nomeVertice = (int)nomeV;
                    servidor = retornaServidorV(nomeVertice);
                    
                    TTransport transport = new TSocket("localhost",9090+servidor);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.modificaVertice(nomeV, cor, descricao, peso);
                    System.out.println(retorno);
                    transport.close();
                }
                if(i==7){
                    System.out.println("Informe o id,peso,descricao da aresta a ser modificado");
                    id=ler.nextLong();
                    peso=ler.nextDouble();
                    descricao=ler.next();
                    
                    TTransport transport = new TSocket("localhost",9093);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.modificaAresta(id, peso, descricao);
                    System.out.println(retorno);
                    transport.close();
                }
                if(i==8){
                    TTransport transport = new TSocket("localhost",9093);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    System.out.println("Informe o id  da aresta");
                    id=ler.nextLong();
                    retorno = client.listaVertice(id);
                    System.out.println(retorno);
                    transport.close();
                }
                if(i==9){
                    
                    System.out.println("Informe o nome do vertice");
                    nomeV=ler.nextLong();
                    
                    nomeVertice = (int)nomeV;
                    servidor = retornaServidorV(nomeVertice);
                    
                    TTransport transport = new TSocket("localhost",9090+servidor);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.listaAresta(nomeV);
                    System.out.println(retorno);
                    transport.close();
                    
                }
                if(i==10){
                    System.out.println("Informe o nome do vertice");
                    nomeV=ler.nextLong();
                    
                    nomeVertice = (int)nomeV;
                    servidor = retornaServidorV(nomeVertice);
                    
                    TTransport transport = new TSocket("localhost",9090+servidor);
                    transport.open();
                    TProtocol protocol = new TBinaryProtocol( transport );
                    Grafosd.Client client = new Grafosd.Client(protocol);
                    
                    retorno = client.listaVizinhos(nomeV);
                    System.out.println(retorno);
                    transport.close();
                }
            }
        } catch ( TException x ) {
        x.printStackTrace() ;
        }
    }
    
    public static int retornaServidorV(int verticeNome) throws UnsupportedEncodingException, NoSuchAlgorithmException
    {
        
            int vetValores[] = new int[32];
            int j;
            int soma=0;
            String servidorAux = Integer.toHexString(verticeNome);
            
            
            byte[] bytesOfMessage = servidorAux.getBytes("UTF-8");

            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] thedigest = md.digest(bytesOfMessage);
            
            for(j=0; j<thedigest.length; j++)
            {
                vetValores[j] = thedigest[j];
                
            }
            
            for(j=0; j<thedigest.length; j++)
            {
                soma += vetValores[j];
                
            }
            
            soma = Math.abs(soma%3);
            
            return soma;
    }
    
    public static int retornaServidorA(int verticeNome1, int verticeNome2) throws UnsupportedEncodingException, NoSuchAlgorithmException
    {
        int vetValores[] = new int[32];
        int j;
        int soma1=0;
        int soma2=0;
        
        //soma1
        String servidorAux = Integer.toHexString(verticeNome1);
        byte[] bytesOfMessage = servidorAux.getBytes("UTF-8");

        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] thedigest = md.digest(bytesOfMessage);
            
        for(j=0; j<thedigest.length; j++)
        {
            vetValores[j] = thedigest[j];
                
        }
            
        for(j=0; j<thedigest.length; j++)
        {
            soma1 += vetValores[j];
        }
        
        //soma2
        servidorAux = Integer.toHexString(verticeNome2);
        bytesOfMessage = servidorAux.getBytes("UTF-8");
        md = MessageDigest.getInstance("MD5");
        thedigest = md.digest(bytesOfMessage);
            
        for(j=0; j<thedigest.length; j++)
        {
            vetValores[j] = thedigest[j];
                
        }
            
        for(j=0; j<thedigest.length; j++)
        {
            soma2 += vetValores[j];
        }
            
        soma1 = soma1 + soma2;
            
        soma1 = Math.abs(soma1%3);
            
        return soma1;
    }
}
