/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1sd;

import org.apache.thrift.transport.TTransportException;

/**
 *
 * @author neliton
 */
public class ServidorControle {
    public static void main ( String [] args ) throws InterruptedException, TTransportException 
    {
        Thread servidor1 = new Thread(new GrafoServer(9090));
        servidor1.start();
        
        Thread servidor2 = new Thread(new GrafoServer(9091));
        servidor2.start();
        
        Thread servidor3 = new Thread(new GrafoServer(9092));
        servidor3.start();    
        
        Thread servidor4 = new Thread(new GrafoServer(9093));
        servidor4.start();  
    }
    
}
