/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package t1sd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author neliton
 */
public class DijkstraAlgoritmo 
{
    private final List<Vertice> vertices;
    private final List<Aresta> arestas;
    private Set<Vertice> verticesVisitados;
    private Set<Vertice> verticesNVisitados;
    private Map<Vertice, Vertice> precedentes;
    private Map<Vertice, Double> distancia;

    public DijkstraAlgoritmo(Grafo grafo) {
        // create a copy of the array so that we can operate on this array
        this.vertices = new ArrayList<Vertice>(grafo.vertices);
        this.arestas = new ArrayList<Aresta>(grafo.arestas);
    }
    
    public void executa(Vertice origem) {
        verticesVisitados = new HashSet<Vertice>();
        verticesNVisitados = new HashSet<Vertice>();
        distancia = new HashMap<Vertice, Double>();
        precedentes = new HashMap<Vertice, Vertice>();
        Double dou = Double.valueOf(0);
        distancia.put(origem, dou);
        verticesNVisitados.add(origem);
        System.out.println("tamoNaExecuta");
        while (verticesNVisitados.size() > 0) {
            System.out.println("tamoNaExecuta1");
            Vertice vertice = pegaMenor(verticesNVisitados);
            System.out.println("tamoNaExecuta2");
            System.out.println(vertice.nome); 
            verticesVisitados.add(vertice);
            System.out.println("tamoNaExecuta3");
            verticesNVisitados.remove(vertice);
            System.out.println("tamoNaExecuta4");
            encontraMenorDists(vertice);
            System.out.println("tamoNaExecuta5");
        }
    }
    
    private void encontraMenorDists(Vertice vertice) 
    {
        List<Vertice> adjacentNodes = pegaVizinhos(vertice);
        System.out.println("tamonaEncontra1");
        for (Vertice alvo : adjacentNodes) {
            System.out.println("tamonaEncontra2");
            pegaMenorDist(alvo);
            System.out.println("tamonaEncontra22");
            pegaMenorDist(vertice);
            System.out.println("tamonaEncontra222");
            pegaDist(vertice, alvo);
            System.out.println("tamonaEncontra2222");
            
            if (pegaMenorDist(alvo) > pegaMenorDist(vertice)+ pegaDist(vertice, alvo)) {
                System.out.println("tamonaEncontra3");
                distancia.put(alvo, (pegaMenorDist(vertice)+ pegaDist(vertice, alvo)));
                System.out.println("tamonaEncontra4");
                precedentes.put(alvo, vertice);
                System.out.println("tamonaEncontra5");
                verticesNVisitados.add(alvo);
                System.out.println("tamonaEncontra6");
            }
        }
        System.out.println("tamonaEncontraSAIU");
    }
    
    private double pegaDist(Vertice vertice, Vertice alvo) {
        for (Aresta aresta : arestas) {
            if ((aresta.origem == vertice.nome) && (aresta.destino == alvo.nome )) {
                return aresta.peso;
            }
            
            else if ((aresta.origem == alvo.nome) && (aresta.destino == vertice.nome )) {
                return aresta.peso;
            }
        }
        throw new RuntimeException("Should not happen");
    }
    
    private List<Vertice> pegaVizinhos(Vertice node) {
        
        List<Vertice> vizinhos = new ArrayList<Vertice>();
        for (Aresta aresta : arestas) {
           for(Vertice verticeAux : vertices)
                {
                    if(verticeAux.nome == aresta.destino)
                    {
                        if ((aresta.origem == node.nome) && (!foiVisitado(verticeAux))) {
                            vizinhos.add(verticeAux);
                            return vizinhos;
                        }
                    }
                    else if(verticeAux.nome == aresta.origem)
                    {
                        if ((aresta.destino == node.nome) && (!foiVisitado(verticeAux))) {
                            vizinhos.add(verticeAux);
                            return vizinhos;
                        }
                    }
                }
                
            }
       return vizinhos;
    }
    
    private Vertice pegaMenor(Set<Vertice> vertices) {
        Vertice minimo = null;
        for (Vertice vertice : vertices) {
            if (minimo == null) {
                minimo = vertice;
            } else {
                if (pegaMenorDist(vertice) < pegaMenorDist(minimo)) {
                        minimo = vertice;
                }
            }
        }
        return minimo;
    }
    
    private boolean foiVisitado(Vertice vertice) {
        return verticesVisitados.contains(vertice);
    }

    private double pegaMenorDist(Vertice destino) {
     
        Double d = distancia.get(destino);
        if (d == null) {
            return Double.MAX_VALUE;
        } else {
            return d;
        }
    }
    
    public LinkedList<Vertice> pegaCaminho(Vertice alvo) {
        LinkedList<Vertice> path = new LinkedList<Vertice>();
        Vertice prox = alvo;
        System.out.println("okkcaminhi1");
        // check if a path exists
        if (precedentes.get(prox) == null) {
            System.out.println("okkcaminhi12");
            return null;
        }
        System.out.println("okkcaminhi3");
        path.add(prox);
        System.out.println("okkcaminhi4");
        while (precedentes.get(prox) != null) {
            System.out.println("okkcaminhi5");
            prox = precedentes.get(prox);
            System.out.println("okkcaminhi6");
            path.add(prox);
        }
        // Put it into the correct order
        Collections.reverse(path);
        return path;
    }
    
    
    
}
