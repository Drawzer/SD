package t1sd;
/**
 *
 * @author patrick
 */
import java.util.ArrayList;
import t1sd.*;

import org.apache.thrift.server.TServer ;
import org . apache . thrift . transport . TServerSocket ;
import org . apache . thrift . transport . TServerTransport ;
import org . apache . thrift . server . TServer . Args ;
import org . apache . thrift . server . TSimpleServer ;
import org . apache . thrift . server . TThreadPoolServer ;
import java . util . HashMap ;
import java.util.List;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.thrift.transport.TTransportException;



public class GrafoServer implements Runnable{
    public int porta;
    
    public GrafoServer(int porta)
    {
        this.porta = porta;
    }
    
    public void run() {
        try {
            TServerTransport serverTransport ;
            serverTransport = new TServerSocket (porta);
            Handler h = new Handler();
            Grafosd.Processor processor = new Grafosd.Processor(h);
            //TServer server = new TSimpleServer ( new Args ( serverTransport ).processor ( processor ) );
            TServer server = new TThreadPoolServer(new TThreadPoolServer.Args(serverTransport).processor(processor));
            T1SD arq = new T1SD();
            List<Vertice> vertices = new ArrayList<Vertice>();
            List<Aresta> arestas = new ArrayList<Aresta>();
            Grafo g = new Grafo(vertices,arestas);
            h.criaGrafo(g);
            System.out.println("Startando servidor na porta: "+porta);
            
            server.serve();
            
            //arq.salvar(g,"/home/neliton/Downloads/t1sd/grafo");
            System.out.println("cabo");
        }catch ( Exception x) {
            x. printStackTrace () ;
           
        }
    }
    /*public static Handler handler;
    public static Grafosd.Processor processor;
    
    public static void main(String[] args)
    {
        try {
        handler = new Handler();
        processor = new Grafosd.Processor(handler);
        
        Runnable simple = new Runnable()
        {
            public void run()
            {
                try {
                    simple(processor);
                } catch (TTransportException ex) {
                    Logger.getLogger(GrafoServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };
        new Thread(simple).start();
        }catch(Exception x){
            x.printStackTrace()
        }
    }
    
     public static void simple(Grafosd.Processor processor) throws TTransportException     
     {
         TServerTransport serverTransport = new TServerSocket(9090);
         TServer server = new TThreadPoolServer(new TThreadPoolServer.Args(serverTransport).processor(processor));
         System.out.println("Iniciando o servidor1 !");
         TServerTransport serverTransport2 = new TServerSocket(9091);
         TServer server2 = new TThreadPoolServer(new TThreadPoolServer.Args(serverTransport2).processor(processor));
         System.out.println("Iniciando o servidor2 !");
         TServerTransport serverTransport3 = new TServerSocket(9092);
         TServer server3 = new TThreadPoolServer(new TThreadPoolServer.Args(serverTransport3).processor(processor));
         System.out.println("Iniciando o servidor3 !");
         
         server.serve();
     }*/

       
}

